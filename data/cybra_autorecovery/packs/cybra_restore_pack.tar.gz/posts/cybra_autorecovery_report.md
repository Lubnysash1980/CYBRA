# CYBRA AutoRecovery Committee Report

Status: restored

OK: False
Committee: cybra_autorecovery_committee
Restore script: cybra_termux_restore.sh
Home copy: /data/data/com.termux/files/home/cybra_termux_restore.sh
Restore pack: data/cybra_autorecovery/restore_pack/cybra_restore_pack_v2.tar.gz

## Restore files
restore_script_exists: False
home_restore_script_exists: False
restore_pack_exists: False

## Modules
cybra_recovery: True
cybra_recover_binary: True
cybra_autorecovery_handler: False
cybra_termux_restore: False
redis_committee: True
autoheal: True
security_analytics: True
conformation8: True
cold_finance: True
kybra_valid: True
payment_requisites: True
market_collector: True
price_gate: True
kibra_stats: True
closed_sha_bridge: True

## Queues
autorecovery_audit: 2
block_inbox: 0
task_block_mempool: 0
pool_mining_blocks: 19
parliament_queue: 0
parliament_failed: 0

## Git
remote_exists: True
token_exposed: False

## Usage
bash cybra_termux_restore.sh
bash ~/cybra_termux_restore.sh
CYBRA_REPO_URL=https://github.com/Lubnysash1980/CYBRA.git CYBRA_BRANCH=main bash ~/cybra_termux_restore.sh

## Safety
private_identity_included: False
private_keys_included: False
seed_phrase_included: False
github_token_included: False
real_payment_now: False
automatic_SWIFT: False
automatic_external_tx: False
manual_OWNER_approval_required: True

## Double SHA
8db12f4c5fea0d51b165b0097d821240ad7aa83752cba2f0057bebada0b7bd40