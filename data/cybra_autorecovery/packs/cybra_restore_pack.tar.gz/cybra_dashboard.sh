#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$HOME/CYBRA"

case "${1:-status}" in
  status)
    python3 cybra_dashboard.py status
    ;;
  report)
    python3 cybra_dashboard.py report
    cat posts/cybra_dashboard_report.md
    ;;
  start)
    PORT="${2:-8099}"
    HOST="${3:-127.0.0.1}"
    mkdir -p logs/cybra_dashboard runtime
    nohup python3 cybra_dashboard.py serve --host "$HOST" --port "$PORT" > logs/cybra_dashboard/dashboard.log 2>&1 &
    echo $! > runtime/cybra_dashboard.pid
    echo "✅ CYBRA Dashboard started"
    echo "URL: http://$HOST:$PORT"
    echo "PID: $(cat runtime/cybra_dashboard.pid)"
    echo "LOG: logs/cybra_dashboard/dashboard.log"
    ;;
  stop)
    if [ -f runtime/cybra_dashboard.pid ]; then
      kill "$(cat runtime/cybra_dashboard.pid)" 2>/dev/null || true
      rm -f runtime/cybra_dashboard.pid
    fi
    echo "✅ CYBRA Dashboard stopped"
    ;;
  restart)
    bash cybra_dashboard.sh stop || true
    bash cybra_dashboard.sh start "${2:-8099}" "${3:-127.0.0.1}"
    ;;
  log)
    tail -f logs/cybra_dashboard/dashboard.log
    ;;
  task)
    shift
    python3 cybra_dashboard.py task "$@"
    ;;
  proof)
    cat proofs/cybra_dashboard.sha256
    ;;
  *)
    echo "Usage:"
    echo "  bash cybra_dashboard.sh status"
    echo "  bash cybra_dashboard.sh report"
    echo "  bash cybra_dashboard.sh start 8099"
    echo "  bash cybra_dashboard.sh stop"
    echo "  bash cybra_dashboard.sh restart 8099"
    echo "  bash cybra_dashboard.sh task 'AI task text'"
    ;;
esac
