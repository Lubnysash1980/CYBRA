#!/data/data/com.termux/files/usr/bin/bash
set +e
cd "$HOME/CYBRA" || exit 1

CMD="${1:-status}"

case "$CMD" in
  status)
    if [ -f cybra_recovery.sh ]; then
      bash cybra_recovery.sh status
    elif [ -x bin/cybra-recover ]; then
      bin/cybra-recover status
    else
      echo "CYBRA AutoRecovery module missing"
      exit 1
    fi
    ;;
  report)
    if [ -f cybra_recovery.sh ]; then
      bash cybra_recovery.sh report || bin/cybra-recover report
    else
      bin/cybra-recover report
    fi
    ;;
  test)
    if [ -x bin/cybra-recover ]; then
      bin/cybra-recover test
    elif [ -f cybra_recovery.sh ]; then
      bash cybra_recovery.sh report
    else
      echo "Recovery module missing"
      exit 1
    fi
    ;;
  pack|make-pack)
    if [ -x bin/cybra-recover ]; then
      bin/cybra-recover make-pack
    else
      bash cybra_recovery.sh pack
    fi
    ;;
  cycle)
    echo "=== CYBRA MENU RECOVERY CYCLE ==="
    bash cybra_menu_recovery_bridge.sh status || true
    bash cybra_menu_recovery_bridge.sh report || true
    bash cybra_menu_recovery_bridge.sh pack || true
    bash cybra_menu_recovery_bridge.sh test || true
    [ -f cybra_autoheal.sh ] && bash cybra_autoheal.sh cycle || true
    [ -f cybra_security_analytics.sh ] && bash cybra_security_analytics.sh cycle || true
    [ -f cybra_menubar.sh ] && bash cybra_menubar.sh report || true
    ;;
  *)
    echo "Usage:"
    echo "  bash cybra_menu_recovery_bridge.sh status"
    echo "  bash cybra_menu_recovery_bridge.sh report"
    echo "  bash cybra_menu_recovery_bridge.sh test"
    echo "  bash cybra_menu_recovery_bridge.sh pack"
    echo "  bash cybra_menu_recovery_bridge.sh cycle"
    ;;
esac
