# Cyberbot

Status: **CYBERBOT_STATUS_OK**

## Bot

- Alive: `True`
- Supervisor: `CYBRA_BOT_BAR_MENU_OK`
- Bot file: `trading_bot/v64/modules/64/module_64_part_02_Ultimate_Force_Trade_no_window_ACTIVE.mjs`

## Exchanges

- Bybit configured: `True`
- Binance configured: `True`

## Supervision

- IT active: true
- CyberParliament active: true
- Finance audit active: true

## Switches

- PIP mode: `True`
- PIP value: `10`
- Live-order gate: `REQUESTED_AUDIT_AND_OWNER_APPROVAL_REQUIRED`
- Live orders enabled: false

## Safety

- real_trading_now: false
- live_orders_enabled: false
- API keys local only: true
